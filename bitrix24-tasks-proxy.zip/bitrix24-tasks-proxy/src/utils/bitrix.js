import fetch from "node-fetch"

const BITRIX_URL = process.env.BITRIX_WEBHOOK_URL

export async function callBitrix(method, params) {
  const url = `${BITRIX_URL}/${method}`
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(params)
  })
  const data = await res.json()
  if (data.error) {
    throw new Error(data.error_description || "Ошибка Bitrix")
  }
  return data.result
}
