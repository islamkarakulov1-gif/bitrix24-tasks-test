import express from "express"
import dotenv from "dotenv"
import tasksRouter from "./routes/tasks.js"
import commentsRouter from "./routes/comments.js"

dotenv.config()
const app = express()

app.use(express.json())

// простая проверка API ключа
app.use((req, res, next) => {
  const apiKey = req.headers["x-api-key"]
  if (apiKey !== process.env.API_KEY) {
    return res.status(401).json({
      error: { code: "UNAUTHORIZED", message: "Неверный API ключ" }
    })
  }
  next()
})

app.use("/tasks", tasksRouter)
app.use("/tasks", commentsRouter)

const port = process.env.PORT || 8080
app.listen(port, () => console.log(`🚀 Server started on port ${port}`))
