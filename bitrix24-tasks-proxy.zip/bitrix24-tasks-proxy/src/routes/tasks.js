import { Router } from "express"
import { callBitrix } from "../utils/bitrix.js"

const router = Router()

router.post("/", async (req, res) => {
  const { title, description, assignee_id, priority, due_at } = req.body
  if (!title) return res.status(400).json({ error: { code: "VALIDATION_ERROR", message: "title is required" } })

  try {
    const task = await callBitrix("tasks.task.add", {
      fields: {
        TITLE: title,
        DESCRIPTION: description || "",
        RESPONSIBLE_ID: assignee_id,
        PRIORITY: priority === "high" ? 2 : priority === "low" ? 0 : 1,
        DEADLINE: due_at
      }
    })
    res.json({ id: task.task.id, title, description, assignee_id, priority, due_at })
  } catch (e) {
    res.status(500).json({ error: { code: "BITRIX_ERROR", message: e.message } })
  }
})

router.get("/", async (req, res) => {
  const { status, assignee, limit = 10, offset = 0 } = req.query
  try {
    const tasks = await callBitrix("tasks.task.list", {
      filter: {
        STATUS: status,
        RESPONSIBLE_ID: assignee
      },
      start: offset
    })
    res.json({ data: tasks.tasks.slice(0, limit) })
  } catch (e) {
    res.status(500).json({ error: { code: "BITRIX_ERROR", message: e.message } })
  }
})

router.get("/:id", async (req, res) => {
  try {
    const task = await callBitrix("tasks.task.get", { taskId: req.params.id })
    res.json(task.task)
  } catch (e) {
    res.status(404).json({ error: { code: "NOT_FOUND", message: e.message } })
  }
})

router.patch("/:id", async (req, res) => {
  try {
    await callBitrix("tasks.task.update", { taskId: req.params.id, fields: req.body })
    res.json({ success: true })
  } catch (e) {
    res.status(400).json({ error: { code: "BITRIX_ERROR", message: e.message } })
  }
})

router.delete("/:id", async (req, res) => {
  try {
    await callBitrix("tasks.task.complete", { taskId: req.params.id })
    res.json({ success: true, strategy: "close" })
  } catch (e) {
    res.status(500).json({ error: { code: "BITRIX_ERROR", message: e.message } })
  }
})

export default router
