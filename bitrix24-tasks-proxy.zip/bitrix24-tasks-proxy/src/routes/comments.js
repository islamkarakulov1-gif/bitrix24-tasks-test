import { Router } from "express"
import { callBitrix } from "../utils/bitrix.js"

const router = Router()

router.post("/:id/comments", async (req, res) => {
  try {
    const { body } = req.body
    if (!body) return res.status(400).json({ error: { code: "VALIDATION_ERROR", message: "body is required" } })
    const result = await callBitrix("task.commentitem.add", {
      taskId: req.params.id,
      fields: { POST_MESSAGE: body }
    })
    res.json({ id: result.comment.id, body })
  } catch (e) {
    res.status(500).json({ error: { code: "BITRIX_ERROR", message: e.message } })
  }
})

router.get("/:id/comments", async (req, res) => {
  const { limit = 20, offset = 0 } = req.query
  try {
    const comments = await callBitrix("task.commentitem.getlist", {
      taskId: req.params.id
    })
    res.json({ data: comments.slice(offset, offset + limit) })
  } catch (e) {
    res.status(500).json({ error: { code: "BITRIX_ERROR", message: e.message } })
  }
})

export default router
