# Bitrix24 Tasks Proxy API

Маленький сервис для работы с задачами Bitrix24 через входящий вебхук.

---

## 🚀 Запуск

1. git clone https://github.com/username/bitrix24-tasks-proxy.git
2. cd bitrix24-tasks-proxy
3. npm install
4. скопировать .env.example в .env и заполнить

```
PORT=8080
API_KEY=supersecret
BITRIX_WEBHOOK_URL=https://yourdomain.bitrix24.ru/rest/1/xxxTOKENxxx
```

5. npm run dev

или через Docker:

```
docker build -t bitrix-proxy .
docker run -p 8080:8080 --env-file .env bitrix-proxy
```

---

## 🔑 Эндпоинты

- POST   /tasks
- GET    /tasks
- GET    /tasks/:id
- PATCH  /tasks/:id
- DELETE /tasks/:id
- POST   /tasks/:id/comments
- GET    /tasks/:id/comments

---

## 📊 Маппинг полей

| Наш API     | Bitrix поле      | Примечание                |
|-------------|------------------|----------------------------|
| id          | ID               | число                     |
| title       | TITLE            | строка                    |
| description | DESCRIPTION      | строка                    |
| assignee_id | RESPONSIBLE_ID   | id пользователя           |
| priority    | PRIORITY         | 0 low / 1 normal / 2 high |
| status      | STATUS           | 1–6 по Bitrix             |
| due_at      | DEADLINE         | ISO8601                   |
| created_at  | CREATED_DATE     | ISO8601                   |
| updated_at  | CHANGED_DATE     | ISO8601                   |
| comment.body| POST_MESSAGE     | текст                     |

---

## 🧪 Примеры

Создание задачи:
```
curl -X POST http://localhost:8080/tasks   -H "Content-Type: application/json"   -H "X-API-Key: supersecret"   -d '{ "title": "Написать отчёт", "assignee_id": 12 }'
```

Добавить комментарий:
```
curl -X POST http://localhost:8080/tasks/42/comments   -H "Content-Type: application/json"   -H "X-API-Key: supersecret"   -d '{ "body": "проверил, всё ок" }'
```

---

## 🗑️ Удаление

Стратегия: закрываем задачу (`tasks.task.complete`).

---

## ⚠️ Ошибки

```
{ "error": { "code": "VALIDATION_ERROR", "message": "Поле kpi не поддерживается" } }
```
